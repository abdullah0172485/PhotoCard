export const TEMPLATE = {
  src: "/template.jpg",
  width: 1080,
  height: 1322,
  circle: {
    cx: 539.2,
    cy: 467.2,
    r: 269,
  },
} as const;

export const PHOTO_SCALE_MIN = 1;
export const PHOTO_SCALE_MAX = 3;

export function coverRatios(naturalWidth: number, naturalHeight: number) {
  return {
    coverW: Math.max(1, naturalWidth / naturalHeight),
    coverH: Math.max(1, naturalHeight / naturalWidth),
  };
}

export function panLimits(naturalWidth: number, naturalHeight: number, scale: number) {
  const { coverW, coverH } = coverRatios(naturalWidth, naturalHeight);
  return {
    maxOx: Math.max(0, coverW * scale - 1),
    maxOy: Math.max(0, coverH * scale - 1),
  };
}
