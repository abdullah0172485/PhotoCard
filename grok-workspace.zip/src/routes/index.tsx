import { createFileRoute } from "@tanstack/react-router";
import { PhotoStudio } from "@/components/photo-studio";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <main className="min-h-dvh">
      <PhotoStudio />
    </main>
  );
}
