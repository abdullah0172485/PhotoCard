import { useCallback, useEffect, useMemo, useRef, useState, type DragEvent, type PointerEvent } from "react";
import { Camera, Download, ImagePlus, Move, RotateCcw, ZoomIn } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  PHOTO_SCALE_MAX,
  PHOTO_SCALE_MIN,
  TEMPLATE,
  coverRatios,
  panLimits,
} from "@/lib/template";
import { clamp, cn } from "@/lib/utils";

type Photo = {
  url: string;
  width: number;
  height: number;
  image: HTMLImageElement;
};

const { width: CARD_W, height: CARD_H, circle } = TEMPLATE;
const leftPct = ((circle.cx - circle.r) / CARD_W) * 100;
const topPct = ((circle.cy - circle.r) / CARD_H) * 100;
const widthPct = ((circle.r * 2) / CARD_W) * 100;
const heightPct = ((circle.r * 2) / CARD_H) * 100;

function loadPhoto(file: File): Promise<Photo> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const image = new Image();
    image.onload = () => {
      resolve({
        url,
        width: image.naturalWidth,
        height: image.naturalHeight,
        image,
      });
    };
    image.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("read-failed"));
    };
    image.src = url;
  });
}

export function PhotoStudio() {
  const inputRef = useRef<HTMLInputElement>(null);
  const circleRef = useRef<HTMLButtonElement>(null);
  const templateRef = useRef<HTMLImageElement | null>(null);
  const dragRef = useRef<{ x: number; y: number; ox: number; oy: number } | null>(null);
  const pinchRef = useRef<number | null>(null);

  const [photo, setPhoto] = useState<Photo | null>(null);
  const [scale, setScale] = useState(1);
  const [ox, setOx] = useState(0);
  const [oy, setOy] = useState(0);
  const [busy, setBusy] = useState(false);
  const [downloaded, setDownloaded] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [dragging, setDragging] = useState(false);

  useEffect(() => {
    const img = new Image();
    img.src = TEMPLATE.src;
    img.onload = () => {
      templateRef.current = img;
    };
  }, []);

  useEffect(() => {
    return () => {
      if (photo) URL.revokeObjectURL(photo.url);
    };
  }, [photo]);

  const limits = useMemo(
    () => (photo ? panLimits(photo.width, photo.height, scale) : { maxOx: 0, maxOy: 0 }),
    [photo, scale],
  );

  useEffect(() => {
    setOx((value) => clamp(value, -limits.maxOx, limits.maxOx));
    setOy((value) => clamp(value, -limits.maxOy, limits.maxOy));
  }, [limits.maxOx, limits.maxOy]);

  const applyFile = useCallback(async (file: File | undefined) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setError("শুধু ছবির ফাইল আপলোড করুন।");
      return;
    }
    if (file.size > 20 * 1024 * 1024) {
      setError("ছবিটি একটু বড়। ২০ এমবি-র নিচে একটি ছবি দিন।");
      return;
    }
    setError(null);
    try {
      const next = await loadPhoto(file);
      setPhoto((prev) => {
        if (prev) URL.revokeObjectURL(prev.url);
        return next;
      });
      setScale(1);
      setOx(0);
      setOy(0);
    } catch {
      setError("এই ছবিটি পড়া যায়নি। আরেকটি ছবি চেষ্টা করুন।");
    }
  }, []);

  const openPicker = useCallback(() => {
    inputRef.current?.click();
  }, []);

  const resetView = useCallback(() => {
    setScale(1);
    setOx(0);
    setOy(0);
  }, []);

  const onPointerDown = useCallback(
    (event: PointerEvent<HTMLButtonElement>) => {
      if (!photo) return;
      event.currentTarget.setPointerCapture(event.pointerId);
      dragRef.current = { x: event.clientX, y: event.clientY, ox, oy };
      setDragging(true);
    },
    [ox, oy, photo],
  );

  const onPointerMove = useCallback(
    (event: PointerEvent<HTMLButtonElement>) => {
      if (!photo || !dragRef.current || pinchRef.current) return;
      const rect = event.currentTarget.getBoundingClientRect();
      const radius = rect.width / 2;
      if (radius <= 0) return;
      const dx = (event.clientX - dragRef.current.x) / radius;
      const dy = (event.clientY - dragRef.current.y) / radius;
      setOx(clamp(dragRef.current.ox + dx, -limits.maxOx, limits.maxOx));
      setOy(clamp(dragRef.current.oy + dy, -limits.maxOy, limits.maxOy));
    },
    [limits.maxOx, limits.maxOy, photo],
  );

  const endDrag = useCallback(() => {
    dragRef.current = null;
    setDragging(false);
  }, []);

  useEffect(() => {
    const el = circleRef.current;
    if (!el) return;

    const distance = (touches: TouchList) =>
      Math.hypot(
        touches[0].clientX - touches[1].clientX,
        touches[0].clientY - touches[1].clientY,
      );

    const onTouchStart = (event: TouchEvent) => {
      if (event.touches.length === 2) {
        pinchRef.current = distance(event.touches);
        dragRef.current = null;
      }
    };

    const onTouchMove = (event: TouchEvent) => {
      if (event.touches.length === 2 && pinchRef.current) {
        event.preventDefault();
        const next = distance(event.touches);
        const ratio = next / pinchRef.current;
        pinchRef.current = next;
        setScale((value) => clamp(value * ratio, PHOTO_SCALE_MIN, PHOTO_SCALE_MAX));
      }
    };

    const onTouchEnd = (event: TouchEvent) => {
      if (event.touches.length < 2) pinchRef.current = null;
    };

    const onWheel = (event: WheelEvent) => {
      if (!photo) return;
      event.preventDefault();
      const delta = -event.deltaY * 0.0016;
      setScale((value) => clamp(value + delta, PHOTO_SCALE_MIN, PHOTO_SCALE_MAX));
    };

    el.addEventListener("touchstart", onTouchStart, { passive: true });
    el.addEventListener("touchmove", onTouchMove, { passive: false });
    el.addEventListener("touchend", onTouchEnd);
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => {
      el.removeEventListener("touchstart", onTouchStart);
      el.removeEventListener("touchmove", onTouchMove);
      el.removeEventListener("touchend", onTouchEnd);
      el.removeEventListener("wheel", onWheel);
    };
  }, [photo]);

  const downloadCard = useCallback(async () => {
    if (!photo) {
      setError("আগে আপনার ছবি যোগ করুন।");
      return;
    }
    const template = templateRef.current;
    if (!template) {
      setError("টেমপ্লেট এখনো লোড হয়নি। একটু পরে আবার চেষ্টা করুন।");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const canvas = document.createElement("canvas");
      canvas.width = CARD_W;
      canvas.height = CARD_H;
      const ctx = canvas.getContext("2d");
      if (!ctx) throw new Error("canvas");
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = "high";
      ctx.drawImage(template, 0, 0, CARD_W, CARD_H);
      ctx.save();
      ctx.beginPath();
      ctx.arc(circle.cx, circle.cy, circle.r, 0, Math.PI * 2);
      ctx.closePath();
      ctx.clip();
      const { coverW, coverH } = coverRatios(photo.width, photo.height);
      const diameter = circle.r * 2;
      const drawW = coverW * scale * diameter;
      const drawH = coverH * scale * diameter;
      const x = circle.cx - drawW / 2 + ox * circle.r;
      const y = circle.cy - drawH / 2 + oy * circle.r;
      ctx.drawImage(photo.image, x, y, drawW, drawH);
      ctx.restore();

      const blob = await new Promise<Blob | null>((resolve) =>
        canvas.toBlob(resolve, "image/png"),
      );
      if (!blob) throw new Error("blob");
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "sreepur-miloni-2027.png";
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
      setDownloaded(true);
      window.setTimeout(() => setDownloaded(false), 2200);
    } catch {
      setError("ডাউনলোড করা যায়নি। আবার চেষ্টা করুন।");
    } finally {
      setBusy(false);
    }
  }, [ox, oy, photo, scale]);

  const { coverW, coverH } = photo
    ? coverRatios(photo.width, photo.height)
    : { coverW: 1, coverH: 1 };
  const imgW = coverW * scale;
  const imgH = coverH * scale;

  const onDrop = useCallback(
    (event: DragEvent) => {
      event.preventDefault();
      void applyFile(event.dataTransfer.files[0]);
    },
    [applyFile],
  );

  return (
    <div
      className="mx-auto grid min-h-dvh w-full max-w-5xl grid-cols-1 gap-5 px-4 pb-28 pt-5 lg:grid-cols-[minmax(0,26rem)_minmax(0,1fr)] lg:grid-rows-[auto_auto_auto] lg:items-center lg:gap-x-12 lg:gap-y-5 lg:pb-8 lg:pt-8"
      onDragOver={(event) => event.preventDefault()}
      onDrop={onDrop}
    >
      <header className="rise space-y-2 text-center lg:col-start-2 lg:row-start-1 lg:text-left">
        <p className="text-sm font-medium tracking-wide text-primary">
          স্থাপিত ১৯৯৩ · পূর্ণ মিলনী ২০২৭
        </p>
        <h1 className="font-display text-2xl font-semibold leading-tight text-fg sm:text-3xl">
          শ্রীপুর আদর্শ মাধ্যমিক বিদ্যালয়
        </h1>
        <p className="text-base text-muted">
          মাঝখানের বৃত্তে নিজের ছবি বসিয়ে মিলনীর কার্ড তৈরি করুন, তারপর ডাউনলোড করে শেয়ার করুন।
        </p>
      </header>

      <div className="rise rise-1 relative mx-auto w-full max-w-md lg:col-start-1 lg:row-span-3 lg:row-start-1 lg:mx-0 lg:max-w-none">
        <div
          className="relative overflow-hidden rounded-xl shadow-[var(--shadow-card)]"
          style={{ aspectRatio: `${CARD_W} / ${CARD_H}` }}
        >
          <img
            src={TEMPLATE.src}
            alt="পূর্ণ মিলনী আমন্ত্রণ কার্ড"
            className="absolute inset-0 size-full select-none"
            draggable={false}
          />
          <button
            ref={circleRef}
            type="button"
            aria-label={photo ? "ছবি সরান বা বদলান" : "ছবি আপলোড করুন"}
            onClick={() => {
              if (!photo) openPicker();
            }}
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={endDrag}
            onPointerCancel={endDrag}
            className={cn(
              "absolute overflow-hidden rounded-full",
              photo ? (dragging ? "cursor-grabbing touch-none" : "cursor-grab touch-none") : "cursor-pointer",
            )}
            style={{
              left: `${leftPct}%`,
              top: `${topPct}%`,
              width: `${widthPct}%`,
              height: `${heightPct}%`,
            }}
          >
            {photo ? (
              <img
                src={photo.url}
                alt="আপনার ছবি"
                draggable={false}
                className="pointer-events-none absolute max-w-none select-none"
                style={{
                  width: `${imgW * 100}%`,
                  height: `${imgH * 100}%`,
                  left: `${((1 - imgW) / 2 + ox * 0.5) * 100}%`,
                  top: `${((1 - imgH) / 2 + oy * 0.5) * 100}%`,
                }}
              />
            ) : (
              <span className="flex size-full flex-col items-center justify-center gap-2 bg-overlay px-4 text-center">
                <Camera className="size-8 text-primary" strokeWidth={1.6} />
                <span className="font-medium leading-snug text-fg">ছবি যোগ করুন</span>
                <span className="text-sm text-muted">ক্যামেরা বা গ্যালারি</span>
              </span>
            )}
          </button>
        </div>
      </div>

      <div className="rise rise-2 space-y-4 lg:col-start-2 lg:row-start-2">
        {photo ? (
          <div className="rounded-xl bg-surface p-4 shadow-[0_0_0_1px_var(--color-border)]">
            <div className="mb-3 flex items-center justify-between gap-3">
              <label htmlFor="zoom" className="flex items-center gap-2 text-sm font-medium">
                <ZoomIn className="size-4 text-primary" />
                জুম
              </label>
              <button
                type="button"
                onClick={resetView}
                className="inline-flex h-10 items-center gap-1.5 rounded-md px-2 text-sm text-muted hover:text-fg"
              >
                <RotateCcw className="size-3.5" />
                রিসেট
              </button>
            </div>
            <input
              id="zoom"
              className="zoom-range"
              type="range"
              min={PHOTO_SCALE_MIN}
              max={PHOTO_SCALE_MAX}
              step={0.01}
              value={scale}
              onChange={(event) => setScale(Number(event.target.value))}
            />
            <p className="mt-2 flex items-center gap-1.5 text-sm text-muted">
              <Move className="size-3.5" />
              ছবি সরাতে বৃত্তের ভিতর টেনে ধরুন
            </p>
          </div>
        ) : null}

        {error ? (
          <p className="rounded-lg bg-surface px-3 py-2 text-sm text-primary" role="alert">
            {error}
          </p>
        ) : null}

        <div className="hidden gap-3 sm:flex">
          <Button variant="secondary" className="flex-1" onClick={openPicker}>
            <ImagePlus />
            {photo ? "ছবি বদলান" : "ছবি আপলোড"}
          </Button>
          <Button className="flex-1" onClick={() => void downloadCard()} disabled={!photo || busy}>
            <Download />
            {busy ? "তৈরি হচ্ছে…" : downloaded ? "ডাউনলোড হয়েছে" : "কার্ড ডাউনলোড"}
          </Button>
        </div>
      </div>

      <footer className="rise rise-3 text-center text-sm text-muted lg:col-start-2 lg:row-start-3 lg:text-left">
        স্মৃতির বন্ধনে আবার একসাথে
      </footer>

      <div className="fixed inset-x-0 bottom-0 z-20 border-t border-border bg-bg/95 p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] sm:hidden">
        <div className="mx-auto flex max-w-lg gap-3">
          <Button variant="secondary" className="flex-1" onClick={openPicker}>
            <ImagePlus />
            {photo ? "বদলান" : "আপলোড"}
          </Button>
          <Button className="flex-1" onClick={() => void downloadCard()} disabled={!photo || busy}>
            <Download />
            {busy ? "হচ্ছে…" : downloaded ? "হয়েছে" : "ডাউনলোড"}
          </Button>
        </div>
      </div>

      <input
        ref={inputRef}
        id="photo-file"
        type="file"
        accept="image/*"
        className="sr-only"
        onChange={(event) => {
          void applyFile(event.target.files?.[0]);
          event.currentTarget.value = "";
        }}
      />
    </div>
  );
}

