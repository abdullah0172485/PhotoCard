//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BW4De5ut.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DwNNc2mg.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DwNNc2mg.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CZSiHKU9.js"]
	}
} });
//#endregion
export { tsrStartManifest };
