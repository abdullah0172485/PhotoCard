import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as ImagePlus, i as Move, o as Download, r as RotateCcw, s as Camera, t as ZoomIn } from "../_libs/lucide-react.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Br4imK1m.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function clamp(value, min, max) {
	return Math.min(max, Math.max(min, value));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg text-sm font-medium transition-[color,background-color,box-shadow,scale,opacity] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-bg disabled:pointer-events-none disabled:opacity-45 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:bg-primary/90 active:scale-[0.96]",
			secondary: "bg-surface text-fg shadow-[0_0_0_1px_var(--color-border)] hover:bg-surface-hover active:scale-[0.96]",
			ghost: "text-fg hover:bg-surface-hover active:scale-[0.96]"
		},
		size: {
			default: "h-11 px-5",
			lg: "h-12 px-6 text-base",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var TEMPLATE = {
	src: "/template.jpg",
	width: 1080,
	height: 1322,
	circle: {
		cx: 539.2,
		cy: 467.2,
		r: 269
	}
};
function coverRatios(naturalWidth, naturalHeight) {
	return {
		coverW: Math.max(1, naturalWidth / naturalHeight),
		coverH: Math.max(1, naturalHeight / naturalWidth)
	};
}
function panLimits(naturalWidth, naturalHeight, scale) {
	const { coverW, coverH } = coverRatios(naturalWidth, naturalHeight);
	return {
		maxOx: Math.max(0, coverW * scale - 1),
		maxOy: Math.max(0, coverH * scale - 1)
	};
}
var { width: CARD_W, height: CARD_H, circle } = TEMPLATE;
var leftPct = (circle.cx - circle.r) / CARD_W * 100;
var topPct = (circle.cy - circle.r) / CARD_H * 100;
var widthPct = circle.r * 2 / CARD_W * 100;
var heightPct = circle.r * 2 / CARD_H * 100;
function loadPhoto(file) {
	return new Promise((resolve, reject) => {
		const url = URL.createObjectURL(file);
		const image = new Image();
		image.onload = () => {
			resolve({
				url,
				width: image.naturalWidth,
				height: image.naturalHeight,
				image
			});
		};
		image.onerror = () => {
			URL.revokeObjectURL(url);
			reject(/* @__PURE__ */ new Error("read-failed"));
		};
		image.src = url;
	});
}
function PhotoStudio() {
	const inputRef = (0, import_react.useRef)(null);
	const circleRef = (0, import_react.useRef)(null);
	const templateRef = (0, import_react.useRef)(null);
	const dragRef = (0, import_react.useRef)(null);
	const pinchRef = (0, import_react.useRef)(null);
	const [photo, setPhoto] = (0, import_react.useState)(null);
	const [scale, setScale] = (0, import_react.useState)(1);
	const [ox, setOx] = (0, import_react.useState)(0);
	const [oy, setOy] = (0, import_react.useState)(0);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [downloaded, setDownloaded] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [dragging, setDragging] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const img = new Image();
		img.src = TEMPLATE.src;
		img.onload = () => {
			templateRef.current = img;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		return () => {
			if (photo) URL.revokeObjectURL(photo.url);
		};
	}, [photo]);
	const limits = (0, import_react.useMemo)(() => photo ? panLimits(photo.width, photo.height, scale) : {
		maxOx: 0,
		maxOy: 0
	}, [photo, scale]);
	(0, import_react.useEffect)(() => {
		setOx((value) => clamp(value, -limits.maxOx, limits.maxOx));
		setOy((value) => clamp(value, -limits.maxOy, limits.maxOy));
	}, [limits.maxOx, limits.maxOy]);
	const applyFile = (0, import_react.useCallback)(async (file) => {
		if (!file) return;
		if (!file.type.startsWith("image/")) {
			setError("শুধু ছবির ফাইল আপলোড করুন।");
			return;
		}
		if (file.size > 20971520) {
			setError("ছবিটি একটু বড়। ২০ এমবি-র নিচে একটি ছবি দিন।");
			return;
		}
		setError(null);
		try {
			const next = await loadPhoto(file);
			setPhoto((prev) => {
				if (prev) URL.revokeObjectURL(prev.url);
				return next;
			});
			setScale(1);
			setOx(0);
			setOy(0);
		} catch {
			setError("এই ছবিটি পড়া যায়নি। আরেকটি ছবি চেষ্টা করুন।");
		}
	}, []);
	const openPicker = (0, import_react.useCallback)(() => {
		inputRef.current?.click();
	}, []);
	const resetView = (0, import_react.useCallback)(() => {
		setScale(1);
		setOx(0);
		setOy(0);
	}, []);
	const onPointerDown = (0, import_react.useCallback)((event) => {
		if (!photo) return;
		event.currentTarget.setPointerCapture(event.pointerId);
		dragRef.current = {
			x: event.clientX,
			y: event.clientY,
			ox,
			oy
		};
		setDragging(true);
	}, [
		ox,
		oy,
		photo
	]);
	const onPointerMove = (0, import_react.useCallback)((event) => {
		if (!photo || !dragRef.current || pinchRef.current) return;
		const radius = event.currentTarget.getBoundingClientRect().width / 2;
		if (radius <= 0) return;
		const dx = (event.clientX - dragRef.current.x) / radius;
		const dy = (event.clientY - dragRef.current.y) / radius;
		setOx(clamp(dragRef.current.ox + dx, -limits.maxOx, limits.maxOx));
		setOy(clamp(dragRef.current.oy + dy, -limits.maxOy, limits.maxOy));
	}, [
		limits.maxOx,
		limits.maxOy,
		photo
	]);
	const endDrag = (0, import_react.useCallback)(() => {
		dragRef.current = null;
		setDragging(false);
	}, []);
	(0, import_react.useEffect)(() => {
		const el = circleRef.current;
		if (!el) return;
		const distance = (touches) => Math.hypot(touches[0].clientX - touches[1].clientX, touches[0].clientY - touches[1].clientY);
		const onTouchStart = (event) => {
			if (event.touches.length === 2) {
				pinchRef.current = distance(event.touches);
				dragRef.current = null;
			}
		};
		const onTouchMove = (event) => {
			if (event.touches.length === 2 && pinchRef.current) {
				event.preventDefault();
				const next = distance(event.touches);
				const ratio = next / pinchRef.current;
				pinchRef.current = next;
				setScale((value) => clamp(value * ratio, 1, 3));
			}
		};
		const onTouchEnd = (event) => {
			if (event.touches.length < 2) pinchRef.current = null;
		};
		const onWheel = (event) => {
			if (!photo) return;
			event.preventDefault();
			const delta = -event.deltaY * .0016;
			setScale((value) => clamp(value + delta, 1, 3));
		};
		el.addEventListener("touchstart", onTouchStart, { passive: true });
		el.addEventListener("touchmove", onTouchMove, { passive: false });
		el.addEventListener("touchend", onTouchEnd);
		el.addEventListener("wheel", onWheel, { passive: false });
		return () => {
			el.removeEventListener("touchstart", onTouchStart);
			el.removeEventListener("touchmove", onTouchMove);
			el.removeEventListener("touchend", onTouchEnd);
			el.removeEventListener("wheel", onWheel);
		};
	}, [photo]);
	const downloadCard = (0, import_react.useCallback)(async () => {
		if (!photo) {
			setError("আগে আপনার ছবি যোগ করুন।");
			return;
		}
		const template = templateRef.current;
		if (!template) {
			setError("টেমপ্লেট এখনো লোড হয়নি। একটু পরে আবার চেষ্টা করুন।");
			return;
		}
		setBusy(true);
		setError(null);
		try {
			const canvas = document.createElement("canvas");
			canvas.width = CARD_W;
			canvas.height = CARD_H;
			const ctx = canvas.getContext("2d");
			if (!ctx) throw new Error("canvas");
			ctx.imageSmoothingEnabled = true;
			ctx.imageSmoothingQuality = "high";
			ctx.drawImage(template, 0, 0, CARD_W, CARD_H);
			ctx.save();
			ctx.beginPath();
			ctx.arc(circle.cx, circle.cy, circle.r, 0, Math.PI * 2);
			ctx.closePath();
			ctx.clip();
			const { coverW, coverH } = coverRatios(photo.width, photo.height);
			const diameter = circle.r * 2;
			const drawW = coverW * scale * diameter;
			const drawH = coverH * scale * diameter;
			const x = circle.cx - drawW / 2 + ox * circle.r;
			const y = circle.cy - drawH / 2 + oy * circle.r;
			ctx.drawImage(photo.image, x, y, drawW, drawH);
			ctx.restore();
			const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/png"));
			if (!blob) throw new Error("blob");
			const url = URL.createObjectURL(blob);
			const link = document.createElement("a");
			link.href = url;
			link.download = "sreepur-miloni-2027.png";
			document.body.appendChild(link);
			link.click();
			link.remove();
			URL.revokeObjectURL(url);
			setDownloaded(true);
			window.setTimeout(() => setDownloaded(false), 2200);
		} catch {
			setError("ডাউনলোড করা যায়নি। আবার চেষ্টা করুন।");
		} finally {
			setBusy(false);
		}
	}, [
		ox,
		oy,
		photo,
		scale
	]);
	const { coverW, coverH } = photo ? coverRatios(photo.width, photo.height) : {
		coverW: 1,
		coverH: 1
	};
	const imgW = coverW * scale;
	const imgH = coverH * scale;
	const onDrop = (0, import_react.useCallback)((event) => {
		event.preventDefault();
		applyFile(event.dataTransfer.files[0]);
	}, [applyFile]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid min-h-dvh w-full max-w-5xl grid-cols-1 gap-5 px-4 pb-28 pt-5 lg:grid-cols-[minmax(0,26rem)_minmax(0,1fr)] lg:grid-rows-[auto_auto_auto] lg:items-center lg:gap-x-12 lg:gap-y-5 lg:pb-8 lg:pt-8",
		onDragOver: (event) => event.preventDefault(),
		onDrop,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "rise space-y-2 text-center lg:col-start-2 lg:row-start-1 lg:text-left",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium tracking-wide text-primary",
						children: "স্থাপিত ১৯৯৩ · পূর্ণ মিলনী ২০২৭"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-2xl font-semibold leading-tight text-fg sm:text-3xl",
						children: "শ্রীপুর আদর্শ মাধ্যমিক বিদ্যালয়"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-base text-muted",
						children: "মাঝখানের বৃত্তে নিজের ছবি বসিয়ে মিলনীর কার্ড তৈরি করুন, তারপর ডাউনলোড করে শেয়ার করুন।"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rise rise-1 relative mx-auto w-full max-w-md lg:col-start-1 lg:row-span-3 lg:row-start-1 lg:mx-0 lg:max-w-none",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative overflow-hidden rounded-xl shadow-[var(--shadow-card)]",
					style: { aspectRatio: `${CARD_W} / ${CARD_H}` },
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: TEMPLATE.src,
						alt: "পূর্ণ মিলনী আমন্ত্রণ কার্ড",
						className: "absolute inset-0 size-full select-none",
						draggable: false
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						ref: circleRef,
						type: "button",
						"aria-label": photo ? "ছবি সরান বা বদলান" : "ছবি আপলোড করুন",
						onClick: () => {
							if (!photo) openPicker();
						},
						onPointerDown,
						onPointerMove,
						onPointerUp: endDrag,
						onPointerCancel: endDrag,
						className: cn("absolute overflow-hidden rounded-full", photo ? dragging ? "cursor-grabbing touch-none" : "cursor-grab touch-none" : "cursor-pointer"),
						style: {
							left: `${leftPct}%`,
							top: `${topPct}%`,
							width: `${widthPct}%`,
							height: `${heightPct}%`
						},
						children: photo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: photo.url,
							alt: "আপনার ছবি",
							draggable: false,
							className: "pointer-events-none absolute max-w-none select-none",
							style: {
								width: `${imgW * 100}%`,
								height: `${imgH * 100}%`,
								left: `${((1 - imgW) / 2 + ox * .5) * 100}%`,
								top: `${((1 - imgH) / 2 + oy * .5) * 100}%`
							}
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex size-full flex-col items-center justify-center gap-2 bg-overlay px-4 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, {
									className: "size-8 text-primary",
									strokeWidth: 1.6
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium leading-snug text-fg",
									children: "ছবি যোগ করুন"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm text-muted",
									children: "ক্যামেরা বা গ্যালারি"
								})
							]
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rise rise-2 space-y-4 lg:col-start-2 lg:row-start-2",
				children: [
					photo ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl bg-surface p-4 shadow-[0_0_0_1px_var(--color-border)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-3 flex items-center justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									htmlFor: "zoom",
									className: "flex items-center gap-2 text-sm font-medium",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomIn, { className: "size-4 text-primary" }), "জুম"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: resetView,
									className: "inline-flex h-10 items-center gap-1.5 rounded-md px-2 text-sm text-muted hover:text-fg",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-3.5" }), "রিসেট"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "zoom",
								className: "zoom-range",
								type: "range",
								min: 1,
								max: 3,
								step: .01,
								value: scale,
								onChange: (event) => setScale(Number(event.target.value))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 flex items-center gap-1.5 text-sm text-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Move, { className: "size-3.5" }), "ছবি সরাতে বৃত্তের ভিতর টেনে ধরুন"]
							})
						]
					}) : null,
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-lg bg-surface px-3 py-2 text-sm text-primary",
						role: "alert",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hidden gap-3 sm:flex",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "secondary",
							className: "flex-1",
							onClick: openPicker,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, {}), photo ? "ছবি বদলান" : "ছবি আপলোড"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							className: "flex-1",
							onClick: () => void downloadCard(),
							disabled: !photo || busy,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), busy ? "তৈরি হচ্ছে…" : downloaded ? "ডাউনলোড হয়েছে" : "কার্ড ডাউনলোড"]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "rise rise-3 text-center text-sm text-muted lg:col-start-2 lg:row-start-3 lg:text-left",
				children: "স্মৃতির বন্ধনে আবার একসাথে"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-x-0 bottom-0 z-20 border-t border-border bg-bg/95 p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] sm:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-lg gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "secondary",
						className: "flex-1",
						onClick: openPicker,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, {}), photo ? "বদলান" : "আপলোড"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "flex-1",
						onClick: () => void downloadCard(),
						disabled: !photo || busy,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), busy ? "হচ্ছে…" : downloaded ? "হয়েছে" : "ডাউনলোড"]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: inputRef,
				id: "photo-file",
				type: "file",
				accept: "image/*",
				className: "sr-only",
				onChange: (event) => {
					applyFile(event.target.files?.[0]);
					event.currentTarget.value = "";
				}
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "min-h-dvh",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoStudio, {})
	});
}
//#endregion
export { Home as component };
